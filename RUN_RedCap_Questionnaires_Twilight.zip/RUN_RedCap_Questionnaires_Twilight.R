### Evaluate screening questionnaires
# save function "RedCap_Questionnaires_Twilight_fun.R somewhere

source("C:/Users/chris/Documents/GitHub/Twilight/RedCap_Questionnaires_Twilight_fun.R")
CHECK <-  Twilight_Screening(p = "C:/Users/chris/switchdrive/Institution/Twilight-Studie_NEU/Redcap/REDCap Exports",
                             d = "BLUMETwilightScreeni_DATA_2022-02-22_1233.csv") # adapt paths
